l = [1,2,3,4,5,10,2]
l.append(100)
l.remove(2)

print (l)

l.pop(0) #removes item at given index
l.pop(2)
l.pop()  #removes item at the end

print (l)
