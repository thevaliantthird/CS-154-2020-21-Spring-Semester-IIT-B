s = {1,2,3}
l = list(s)

print (s,l)


l = ['a','abc',3,4,4,4]
u = set (l)
print (l,u)


