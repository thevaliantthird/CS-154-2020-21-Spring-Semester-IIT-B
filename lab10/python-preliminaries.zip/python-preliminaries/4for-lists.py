l = [1,2,3]
sum = 0
for n in l: 
	sum  = sum + n
	print (n)

print (sum)


