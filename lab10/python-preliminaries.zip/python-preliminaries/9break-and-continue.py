
r = range(0,10)
for e in r:
	if e==3:
		break
	print (e)
else:
	print("for1 done")

print ("==============")

for e in r:
	if e==3:
		continue
	print (e)
else:
	print("for2 done")

