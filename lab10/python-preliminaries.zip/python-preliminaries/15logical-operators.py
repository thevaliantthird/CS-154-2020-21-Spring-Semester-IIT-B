x = 0
y = 20
if x<10 and y>10:
	print ("satisfied")

if x>10 or y>10:
	print ("satisfied")

if not x>10:
	print ("satisfied")
