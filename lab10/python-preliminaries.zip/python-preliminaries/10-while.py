i = 10
while i<20:
	i=i+1
	print (i)

