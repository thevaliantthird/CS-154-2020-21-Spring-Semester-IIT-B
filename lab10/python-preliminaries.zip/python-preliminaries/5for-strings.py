s = "hello"
for c in s: 
	print (c, end = " ")
print ("\n")

