l = [10,20,30,40,50,60]

l2 = l[2:4]
print (l2)

l3 = l[2:]
print (l3)

l4 = l[:3]
print (l4)


