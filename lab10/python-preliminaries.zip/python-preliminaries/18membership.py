l = [1,2,3,4]
l2 = [3,4,5,6]

for e in l:
	if e in l2:
		print (e)


s = "hello world"
for c in s:
	print (c)

