l = [1,2,3]
x=0
for e in l:
	x = x + e
else:
	print (x)

