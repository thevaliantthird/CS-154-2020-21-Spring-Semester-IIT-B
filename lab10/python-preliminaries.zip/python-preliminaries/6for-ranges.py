r = range(10)
for n in r:
	print (n)
print ("------")
r2 = range(3,7)
for n in r2:
	print (n)
print ("-------")
r3 = range (3,21,5)
for n in r3:
	print (n)

