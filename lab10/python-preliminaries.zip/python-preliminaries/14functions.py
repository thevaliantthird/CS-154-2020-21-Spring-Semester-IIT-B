def f (a):
	p = a+1
	return p


x = f(19)

print (x)

