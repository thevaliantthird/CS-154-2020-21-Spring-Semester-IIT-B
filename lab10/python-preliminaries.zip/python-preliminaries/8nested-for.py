l1= range (0,4)
l2= range (8,11)

for i in l1:
	for j in l2:
		print (i,j)

