#this is a comment
#use tab for indentation
#indentation identifies a block
#there are no curly braces {} to
#identify begin and end of blocks
#indentation must be accurate

a = 2
b = 3
if a<b:
	print (a)
	print (b)
else:
	print (b)
	print (a)

print (a)

