l = [1,3,4]
l2 = l

print (l)
del (l)

print (l2)
#print (l)


del (l2)
#print (l2)
