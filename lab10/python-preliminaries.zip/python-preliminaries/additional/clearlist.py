l = [1,2]
l2 = l.copy()   # copy operator 
l.clear()   #clear operator


print (l,l2)
