a = 1
b = 2
c = 4
print (a,b,c),
print (a,b,c,end="\n")
